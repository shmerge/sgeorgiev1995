package cosinetheorem;

import cosinetheorem.SelectionForm;
import java.awt.ComponentOrientation;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gshme
 */
public class Educating extends javax.swing.JFrame {

    String theory[] = {"", "Здравейте! С тази програма ще научите какво е косинусова теорема и как тя ни помага в решаването на задачи.",
        "Нека първо решим следната задача:",
        "В триъгълника ▲ABC AB = 3 cm, BC = 4 cm, ∢ ABC = π/3. Да се намери AC.",
        "Познатата ни синусова теорема не ни помага директно за намиране на страната AC. "
        + "Ето защо можем да подходим по следния начин: построяваме височината CH.",
        "В триъгълник ▲CHB ∢ HCB = π/6, от където следва, че HB = ½ CB = 2 cm (Защо?) и AH = AB – HB = 3 – 2 = 1 cm.",
        "От Питагоровата теорема следва за триъгълник CHB:\n"
        + "〖CH〗^2+〖HB〗^2=〖CB〗^2, от където следва че CH = √12 cm.",
        "От Питагоровата теорема за триъгълник ▲AHC следва:\n"
        + "〖AC〗^2=〖AH〗^2+〖CH〗^2=1+12=13, от където следва че CH = √13 cm.",
        "Обаче това решение е дълго и тромаво. Съществува теорема, която ни помага да решим задачата по-лесно. "
        + "Тя се нарича косинусова теорема.",
        "Теорема: Квадратът на всяка страна в триъгълник е равен на сбора от квадратите на другите две страни минус удвоеното им произведение, умножено по косинуса на ъгъла между тях, т.е ",
        "a^2=b^2+c^2-2*b*c*cosα\n"
        + "b^2=a^2+c^2-2*a*c*cosβ\n"
        + "c^2=a^2+b^2-2*a*b*cosγ",
        "С елементарни преобразувания горната теорема ни дава възможност да намерим: "
        + "страна на триъгълник, ако знаем другите две страни и ъгъл. Трите ъгъла, ако знаем трите страни:",
        "cosα=(b^2+c^2-a^2)/2*b*c\n"
        + "cosβ=(a^2+c^2-b^2)/2*a*c\n"
        + "cosγ=(a^2+b^2-c^2)/2*a*b",
        "Като използваме косинусовата теорема можем да решим задача 1. Дадени са a = 4 cm, c = 3 cm, β = π/3. Търсим страната b.",
        "Задачата се решава изключително лесно:",
        "Избираме нужната за нас формула, а именно: \n",
        "b^2=a^2+c^2-2ac cosβ",
        "След това заместваме зададените стойности за a, b и  cos β и се получава:",
        "4^2+3^2-2*4*3 cos〖60^0〗=16+9-2*4*3*1/2=25-12=13\n b^2=13",
        "b=±√13, но знаем, че страните на триъгълниците са положителни числа, то следва, че b=√13",
        "А сега, за да представим и функциите на другата формула на косинусовата теорема. "
        + "Сега ще намерим косинуса и на другите два ъгъла – α и β. За ъгъл α използваме следната формула:\n"
        + "cosα=(b^2+c^2-a^2)/2*b*c",
        "След това заместваме зададените стойности за a, b и c и се получава:",
        "(〖√13〗^2+3^2-4^2)/(2*√13*3)=(13+9-16)/(6*√13)=6/(6*√13)=1/√13",
        "Сега рационализираме и се получава:",
        "(1/√13)*(√13/√13)=√13/13",
        "cosα=√13/13",
        "Сега правим същите действия и за ъгъл γ",
        "cosγ=(a^2+b^2-c^2)/2*a*b",
        "След това заместваме зададените стойности за a, b и c и се получава:",
        "=(4^2+〖√13〗^2-3^2)/(2*4*√13)=(16+13-9)/(8*√13)=20/(8*√13)=5/(2*√13)",
        "Сега рационализираме и се получава:",
        "5/(2*√13)*√13/√13=(5*√13)/(2*13)=(5*√13)/26",
        "cosγ=(5*√13)/26",
        "С тази задача използвахме възможностите на косинусовата теорема за намиране на "
        + "страна в триъгълник със зададени две страни и един ъгъл. "
        + "А след като намерихме и третата страна лесно намерихме косинусите на другите два ъгъла.",
        "Не е трудно, нали.",
        "Сега е твой ред:",
        "Даден е триъгълник ABC и са дадени b = 5 см., c = 6 см., cosα = 3/4. "
        + "Намерете дължината на третата страна а и косинусите на другите два ъгъла – β и γ.",
        "А сега намери косинуса и на другите два ъгъла – β и γ.",
        "Сега е твой ред. Давай реши задача! И да знаеш - можеш го!\n \n"
        + "P.S. Вече сигурно си видял, че има бутони, където можеш да си проверяваш отговорите."
        + "Много е функционално и яко"};

    int counter = 0;
    int counterHelp = 0;

    String help[] = {"", "Избираме нужната ни формула, а именно:\n"
        + "a^2=b^2+c^2-2*b*c*cosα",
        "След това отново заместваме директно със зададените ни стойности b = 5 см., c = 6 см., cosα = 3/4",
        "5^2+6^2-2*5*6cosα",
        "=25+36-2*5*6*3/4=61-45=16",
        "a^2=16",
        "a=±4, но знаем, че страните на триъгълниците са положителни числа, то следва, че а=4",
        "За ъгъл β използваме следната формула:\n"
        + "cosβ=(a^2+c^2-b^2)/2*a*c",
        "След това заместваме зададените стойности за a, b и c и се получава:\n"
        + "=(4^2+6^2-5^2)/(2*4*6)",
        "=(16+36-25)/48=27/48=9/16,т.е\n"
        + "cosα=9/16",
        "Сега правим същите действия и за ъгъл γ.",
        "cosγ=(a^2+b^2-c^2)/2*a*b",
        "След това заместваме зададените стойности за a, b и c.",
        "И се получава:\n"
        + "=(4^2+5^2-6^2)/(2*4*5)",
        "=(16+25-36)/40=5/40=1/8, т.е. \n cosγ=1/8"
    };

    public Educating() {
        initComponents();
        lblPic1.setVisible(false);
        lblPic2.setVisible(false);
        txtOutput.setLineWrap(true);
        txtOutput.setFont(txtOutput.getFont().deriveFont(16f));
        btnHelp.setEnabled(false);
        jButton1.setEnabled(false);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtOutput = new javax.swing.JTextArea();
        btnNext = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnHelp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnMainMenu = new javax.swing.JButton();
        lblPic1 = new javax.swing.JLabel();
        lblPic2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Знание");
        setResizable(false);

        txtOutput.setEditable(false);
        txtOutput.setColumns(20);
        txtOutput.setRows(5);
        jScrollPane1.setViewportView(txtOutput);

        btnNext.setText("Напред");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnBack.setText("Назад");
        btnBack.setToolTipText("");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnHelp.setText("Помощ");
        btnHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHelpActionPerformed(evt);
            }
        });

        jLabel1.setText("* Бутоните Помощ и Помощ назад ще бъдат активни, когато започнете да решавате задача");

        jButton1.setText("Помощ назад");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnMainMenu.setText("Основно меню");
        btnMainMenu.setToolTipText("");
        btnMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMainMenuActionPerformed(evt);
            }
        });

        lblPic1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cosinetheorem/Триъгълник АБЦ 133.png"))); // NOI18N

        lblPic2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cosinetheorem/Триъгълник АБЦ ОСТЪР 133.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnHelp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBack, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNext, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(34, 34, 34)
                        .addComponent(lblPic1)
                        .addGap(18, 18, 18)
                        .addComponent(lblPic2))
                    .addComponent(btnMainMenu))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnNext)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnBack)
                                .addGap(25, 25, 25)
                                .addComponent(btnHelp)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton1))
                            .addComponent(lblPic1)
                            .addComponent(lblPic2))
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnMainMenu))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed

        //JOptionPane.showMessageDialog(null, Integer.toString(theory.length));
        counter += 1;
        if (counter < theory.length) {
            txtOutput.setText(theory[counter]);

            if (counter >= 3 && counter <= 34) {
                lblPic1.setVisible(true);
            } else {
                lblPic1.setVisible(false);
            }

            if (counter > 34) {
                lblPic2.setVisible(true);
                btnHelp.setEnabled(true);
                jButton1.setEnabled(true);

            } else {
                lblPic2.setVisible(false);
            }

            if (counter > 35) {
                
                btnHelp.setEnabled(true);
                jButton1.setEnabled(true);

            } else {
                btnHelp.setEnabled(false);
                jButton1.setEnabled(false);
            }

        } else {
            counter = theory.length;
        }

    }//GEN-LAST:event_btnNextActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

        counter -= 1;
        if (counter >= 0) {
            txtOutput.setText(theory[counter]);

            if (counter >= 3 && counter <= 34) {
                lblPic1.setVisible(true);
            } else {
                lblPic1.setVisible(false);
            }

            if (counter > 34) {
                lblPic2.setVisible(true);
            } else {
                lblPic2.setVisible(false);
            }
            
            if (counter > 35) {
                
                btnHelp.setEnabled(true);
                jButton1.setEnabled(true);

            } else {
                btnHelp.setEnabled(false);
                jButton1.setEnabled(false);
            }

        } else {
            counter = 0;
        }
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHelpActionPerformed

        counterHelp += 1;
        if (counterHelp < theory.length) {
            txtOutput.setText(help[counterHelp]);

        } else {
            counter = theory.length;
        }

    }//GEN-LAST:event_btnHelpActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        counterHelp -= 1;
        if (counterHelp >= 0) {
            txtOutput.setText(help[counterHelp]);

        } else {
            counter = 0;
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMainMenuActionPerformed

        SelectionForm selForm = new SelectionForm();
        selForm.setLocation(this.getLocation());
        Educating.this.setVisible(true);
        selForm.setVisible(true);

    }//GEN-LAST:event_btnMainMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Educating.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Educating.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Educating.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Educating.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Educating().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnHelp;
    private javax.swing.JButton btnMainMenu;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblPic1;
    private javax.swing.JLabel lblPic2;
    private javax.swing.JTextArea txtOutput;
    // End of variables declaration//GEN-END:variables
}
